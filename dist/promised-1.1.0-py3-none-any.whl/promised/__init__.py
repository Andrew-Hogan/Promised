"""A flexible cached property with get/set/del/init/dependant/cached-mapping capabilities for property relationships."""
from .boiler_property import promise, linked, Member
name = "promised"
